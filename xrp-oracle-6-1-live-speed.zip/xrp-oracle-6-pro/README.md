# XRP Oracle 6.1 Live Speed Edition

Upload `index.html` to your GitHub Pages repository. This version uses the Coinbase public XRP-USD ticker WebSocket for real-time price and active OHLC candle updates, with REST candle reconciliation every 30 seconds. If WebSocket access is blocked, REST updates remain available.

The ticker is not Kalshi settlement data. Indicators are research-only and not forecasts or win probabilities. Candle volume is reconciled from REST, not estimated from ticker messages.
