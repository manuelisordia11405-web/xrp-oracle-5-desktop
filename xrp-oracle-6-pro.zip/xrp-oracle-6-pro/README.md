# XRP Oracle 6.0 Pro — Desktop

A single-file, neon-purple XRP/USD research dashboard for GitHub Pages. Uses Coinbase Exchange public candle data for 1m/5m/15m timeframes, candlestick chart, EMA9/21, RSI14, MACD histogram, Bollinger bands, manual Kalshi target, countdown, zoom, and rule-based directional assessment.

## Publish
1. Create a new public GitHub repository named `xrp-oracle-6-pro`.
2. Upload `index.html` to the repository root (optionally README.md).
3. Settings → Pages → Deploy from a branch → main → /(root) → Save.
4. Wait for the deployment to complete and use the GitHub Pages link shown in Settings → Pages.

## Notes
This is a research tool, not financial advice or a trading bot. Confidence/agreement reflects rule agreement, NOT a calibrated probability. No live Kalshi API integration. Kalshi contracts may settle using a different price index than Coinbase. Browser API requests may fail due to network restrictions or exchange rate limits. No API keys or account credentials required.
